function add()
{
    var a = 10
    var b = 60
    console.log(a+b)
}

add()

var factor = "Kamal"
var fplayer = "Dhoni"
var fmovie = "sivam"
// + or ,
function favourite()
{
    console.log("Favourite Actor:", factor)
    console.log("Favourite player:" ,fplayer)
    console.log("Favourite movie:",fmovie)
}
favourite()

function area(length,breadth)
{
  console.log("area:" + length*breadth)
}
area(20,10)

function myName()
{
    return "John"
}
var a = myName()
console.log(a)


function add(a,b)
{
  return a+b
}
var c = add(2,5)
console.log(c)

//conditional

var rain = true
if(rain)
{
    console.log("take an umbrella")
}
else{
    console.log("enjoy the climate")
}

var hw = false
if(hw){
    console.log("great  job")
}
else
{
    console.log("finish your hw")
}


var color="yellow"
if(color == 'red')
{
    console.log("stop")
}
if(color == 'yellow')
{
    console.log("wait")
}
if(color == 'green')
{
    console.log("go")
}

var season = "spring"
if(season == 'summer')
{
    console.log("have fun")
}
if(season == 'spring')
{
    console.log("enjot the bloom")
}

var score = 54 
if(score <= 50){
    console.log("you need to improve")
}
else if(score>50 && score<=70){
    console.log("good job")
}
else if(score > 70){
    console.log("excellent")
}

var number = 30
if(number%2 == 0)
{
    console.log("even")
}
else
{
    console.log("odd")
}

var character = 'e'
if(character = 'a'|| 'e' || 'i' || 'o' || 'u'){
    console.log("vowels")
}
else{
    console.log("consonant")
}


for(i=2;i<=10;i = i + 2){
    console.log(i)
}
/* 
for(j=1;j<=10;j++){
    console.log(j+"x2="+j*2)
} */
//anothermethod
let n =2
for(j=1;j<=10;j++){
    console.log(j+"x2="+n*j)
}
