let outputScreen = document.getElementById("output-screen");
function display(num){
    outputScreen.value += num;
}

document.querySelector('calculator').addEventListener("click",function(event){

    
    buttonClick(event.target.innerHTML);
});

function Calculate() {
    try{
        outputScreen.value = eval(outputScreen.value);
    }
    catch(err)
    {
        alert("Invalid")
    }
}
function Clear(){
    outputScreen.value = "";
}
function del(){
    outputScreen.value = outputScreen.value.slice(0,-1);
}
function buttonClick(value){
    if(isNaN(parseInt(value))){
        handleSymbol(value);
    }else{
        handleNumber(value);
    }
    rerenderScreen();
}

