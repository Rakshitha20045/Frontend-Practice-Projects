var x= 10;
var y= 26;

console.log(x/y)
var name="rakshi"
console.log(name.length);

var p = 2;
if(p < 5){
    if(p < 1){
        console.log("nested if");
    }else{
        console.log("nested else");
    }
    console.log("true");
}else if(p>=20){
    console.log("neither true not false");
}
else{
    console.log(false);
}

for (var x = 0; x <= 10; x++) {
    console.log(x);
}


var x = prompt("enter a number from 1-3");
var y = parseInt(x);
console.log(typeof y);
console.log(typeof x);
switch(y) {
  case 1:
    console.log("1st will execute");
    break;
  case 2:
    console.log("2nd will execute");
    break;
  case 3:
    console.log("3rd will  execute");
    break;
  default:
    console.log("enter a value");
    break;
}

var name="rakshitha";
console.log(name[4]);

var arr=[100,60,67,89,900]
arr[3]=200;
arr[5]=1000;
arr.pop();
arr.shift();
arr.push(46);
arr.unshift(46);
console.log(arr);

var car = {
    name:'alto',
    year:2004,
    brandname:'maruthi',
};
console.log(car);

var x = 12;
var y = 40;
function add() {
    var z = x+y;
    console.log(z);
}
add();
//call back function
//var btn = document.getElementById("btn");
//btn.addEventListener("focus",color);

//function color() {
  //  heading.style.color="red";
//}
//higher order function
setTimeout(function () {
    console.log("running");
},5000);

//ES6
//arrow function
//var x = () => {
    //console.log("arrow func");
//};
//x();

//template string
 var first="rakshitha";
 var last="A";
 var name=`${first} ${last}`;
 console.log(name);
 
//destructing
var arr=[100,200];
var[one,two]=arr;
console.log(one,two);

var arr = [100,200,300];
var total = 0;
for(var item of arr) {
    total = total + item;
    console.log(total);
}

///let,constant
let a=10;
console.log(a);
{
    let b=50;
    console.log(b);
}
console.log(a);

var c = 20;
c=55;
console.log(c);

//hoisting
add(10,15);
function add(x,y){
    console.log(x+y);
};

let nam ="rakshitha"
for (const alphabet of nam) {
    console.log(alphabet);
}
console.log(nam.includes('r'));
console.log(nam.toUpperCase());


