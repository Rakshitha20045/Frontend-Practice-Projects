const form = document.getElementById('form');
const username = document.getElementById('username');
const email = document.getElementById('email');
const phonenumber = document.getElementById('phonenumber');
const password = document.getElementById('password');
const cpassword = document.getElementById('cpassword');


form.addEventListener('submit', e => {
   
   e.preventDefault();

   validateInputs();
});

const setError = (element,message) => {
    const inputControl = element.parentElemnt;
    const errorDisplay  = inputControl.querySelector('.error');

    errorDisplay.innerText = message;
    inputControl.classList.add('error');
    inputControl.classList.remove('success')
}

const setSuccess =  element =>{
    const inputControl= element.parentElemnt;
    const errorDisplay = inputControl.querySelector('.error');

    errorDisplay.innerText = '';
    inputControl.classList.add('success');
    inputControl.classList.remove('error');
};

const isValidEmail = email => {
    const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}

 

const  validateInputs = () => {
    const usernameValue = username.value.trim();
    const emailValue = email.value.trim();
    const phonenumberValue = phonenumber.value.trim();
    const passwordValue = password.value.trim();
    const cpasswordValue = cpassword.value.trim();
    

    if(usernameValue === '') {
       
        setError(username,'Username is required');
    }
    else{
        setSuccess(username);
    }


    if(emailValue === '') {
       
        setError(email,'Email is required');
    }
    else if(!isValidEmail(emailValue)) {
    
        setError(email,'Please enter a valid email');
    }
    else {
        setSuccess(email);
    }
    
    
    if(passwordValue ===''){
        
        setError(password,'Password is required');
    }
    else if(passwordValue. length  < 8) {
        
        setError(password,'Password must be atleast 8 character')
    }
    else{
        setSuccess(password);
    }

    
    
    if(cpasswordValue ===''){
       
        setError(cpassword,' Confirm Password is required');
    }
    else if(cpasswordValue !== passwordValue) {
        setError(cpassword,'Password does not match');
    }
    else{
        setSuccess(cpassword);
    }
};



